package com.cg.emp.service;

import java.util.List;

import com.cg.emp.dto.Employee;

public interface IEmpService {

	List<Employee> getAllEmp();
	Employee getEmpById(int empId);
	void addEmp(Employee emp);
	void UpdateEmp(Employee emp, int empId);
	void deleteEmp(int empId);

}
