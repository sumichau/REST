package com.cg.emp.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.emp.dto.Employee;
import com.cg.emp.service.EmpServiceImpl;
import com.cg.emp.service.IEmpService;

@RestController
public class EmpController {
	@Autowired
	IEmpService empServiceRef;

	@RequestMapping("/welcome")
	public String welcomeEmp() {
		return "Hello";
	}

	@RequestMapping("/emp")
	public List<Employee> getAllEmps() {
		return (empServiceRef.getAllEmp());
	}
	@RequestMapping("/emp/{empId}")
	public Employee getEmpById(@PathVariable int empId)
	{
		return (empServiceRef.getEmpById(empId));
	}
	@RequestMapping(method=RequestMethod.POST,value="/emp")
	public void addEmp(@RequestBody Employee emp)
	{
		empServiceRef.addEmp(emp);
	}
	@RequestMapping(method=RequestMethod.PUT,value="/emp/{empId}")
	public void UpdateEmp(@RequestBody Employee emp,@PathVariable int empId)
	{
		empServiceRef.UpdateEmp(emp,empId);
	}
	@RequestMapping(method=RequestMethod.DELETE,value="/emp/{empId}")
	public void deleteEmp(@PathVariable int empId)
	{
		empServiceRef.deleteEmp(empId);
	}
}
