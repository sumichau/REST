package com.cg.emp.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.emp.dto.Employee;
@Service
public class EmpServiceImpl implements IEmpService {
List<Employee> empList=new ArrayList<>( Arrays.asList(
		new Employee(1,"su","IT"),
		new Employee(2,"de","dev"),
		new Employee(3,"yp","yo")));

@Override
public List<Employee> getAllEmp() {
	// TODO Auto-generated method stub
	return empList;
}

@Override
public Employee getEmpById(int empId) {
	return empList.stream().filter(e->e.getEmpId()==empId).findFirst().get();
	
}

@Override
public void addEmp(Employee emp) {
	// TODO Auto-generated method stub
	empList.add(emp);
}


@Override
public void deleteEmp(int empId) {
	// TODO Auto-generated method stub
	empList.removeIf(e->e.getEmpId()==empId);
}

@Override
public void UpdateEmp(Employee emp, int empId) {
	// TODO Auto-generated method stub
	for(int i=0;i<empList.size();i++) {
		Employee e=empList.get(i);
		if(e.getEmpId()==empId) {
			empList.set(i, emp);
			return;
		}
	}
}
}
